
import React from "react";
import LiveSocketTicker from "./LiveSocketTicker";

function App() {
  return (
    <div className="App">
      <LiveSocketTicker />
    </div>
  );
}

export default App;
