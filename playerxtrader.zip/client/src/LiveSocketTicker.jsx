
import React, { useEffect, useState } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:5000");

export default function LiveSocketTicker() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    socket.on("liveUpdates", (data) => {
      setEvents((prev) => [...data, ...prev].slice(0, 10));
    });

    return () => {
      socket.off("liveUpdates");
    };
  }, []);

  return (
    <div className="bg-gray-900 text-white p-4">
      <h2 className="text-lg font-bold mb-2">⚡ Live Player Updates</h2>
      {events.length === 0 ? (
        <p>Waiting for live events...</p>
      ) : (
        <ul>
          {events.map((e, i) => (
            <li key={i} className="mb-1">
              <strong>{e.name}</strong> ({e.team}) – <span className="text-green-400">{e.action}</span> at {e.time}' → <span className="text-yellow-300">{e.impact}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
