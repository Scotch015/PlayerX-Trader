
const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const cors = require("cors");
const axios = require("axios");
require("dotenv").config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

app.use(cors());
app.use(express.json());

io.on("connection", (socket) => {
  console.log("⚡ New client connected");

  const fetchLiveData = async () => {
    try {
      const res = await axios.get("https://v3.football.api-sports.io/fixtures", {
        headers: { "x-apisports-key": process.env.FOOTBALL_API_KEY },
        params: { live: "all" },
      });

      const updates = [];

      res.data.response.forEach((match) => {
        match.events?.forEach((e) => {
          if (e.type === "Goal" || (e.type === "Card" && e.detail === "Red Card")) {
            updates.push({
              name: e.player?.name,
              team: e.team.name,
              action: e.type === "Goal" ? "Goal" : "Red Card",
              time: e.time.elapsed,
              impact: e.type === "Goal" ? "+10%" : "-15%",
            });
          }
        });
      });

      if (updates.length > 0) {
        io.emit("liveUpdates", updates);
      }
    } catch (error) {
      console.error("Live fetch failed:", error.message);
    }
  };

  const interval = setInterval(fetchLiveData, 10000);

  socket.on("disconnect", () => {
    console.log("❌ Client disconnected");
    clearInterval(interval);
  });
});

server.listen(5000, () => {
  console.log("Server running on http://localhost:5000");
});
